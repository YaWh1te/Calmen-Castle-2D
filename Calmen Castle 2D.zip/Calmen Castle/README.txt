1. Unpack the archive on your desktop
2. Open Installer Game
3. Enjoy!